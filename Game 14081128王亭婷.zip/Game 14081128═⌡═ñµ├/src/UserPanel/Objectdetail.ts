interface Objectdetail{

    getClassName():String;

    getQualityDescript():String;

    // getAtkDiscript():String;

    // getDefDiscript():string;
}