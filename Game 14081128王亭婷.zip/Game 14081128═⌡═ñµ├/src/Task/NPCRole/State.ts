interface State {

      onEnter();
      
      onExit();
  }
